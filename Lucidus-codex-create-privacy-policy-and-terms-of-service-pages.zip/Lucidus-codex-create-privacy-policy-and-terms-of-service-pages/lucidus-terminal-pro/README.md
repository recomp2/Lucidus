# Lucidus Terminal Pro

A WordPress plugin powering the AI-driven Lucidus command center. This simplified version adds privacy policy and terms of service pages on activation and provides an initiation form shortcode that requires user consent.
