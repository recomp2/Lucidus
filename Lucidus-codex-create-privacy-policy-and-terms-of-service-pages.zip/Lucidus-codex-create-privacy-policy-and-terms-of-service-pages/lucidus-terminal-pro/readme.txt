=== Lucidus Terminal Pro ===
Contributors: lucidus
Requires at least: 6.0
Tested up to: 6.5
Stable tag: 0.1.0
License: MIT

== Description ==
Adds privacy policy and terms of service pages and provides an initiation form shortcode with a required consent checkbox linking to these pages.
