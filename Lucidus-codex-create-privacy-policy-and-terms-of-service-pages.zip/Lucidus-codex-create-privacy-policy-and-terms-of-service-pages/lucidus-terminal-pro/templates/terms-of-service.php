<?php
/*
Template Name: Lucidus Terms of Service
*/
?>
<h2>Terms of Service</h2>
<p>The rules that bind us all.</p>
