<?php
/*
Template Name: Lucidus Privacy Policy
*/
?>
<h2>Privacy Policy</h2>
<p>Your privacy matters.</p>
