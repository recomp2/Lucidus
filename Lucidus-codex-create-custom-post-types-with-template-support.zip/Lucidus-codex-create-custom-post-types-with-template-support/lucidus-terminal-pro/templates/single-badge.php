<?php get_header(); ?>
<main id="primary" class="site-main">
    <h1><?php the_title(); ?></h1>
    <div class="entry-content">
        <?php the_content(); ?>
    </div>
</main>
<?php get_footer(); ?>
