<div class="lpe-prophecy-room">
    <p>Your prophecy will appear here.</p>
</div>
