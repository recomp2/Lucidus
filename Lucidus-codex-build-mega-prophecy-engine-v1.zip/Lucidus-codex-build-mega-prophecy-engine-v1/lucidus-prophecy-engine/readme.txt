=== Lucidus Prophecy Engine ===
Contributors: Dead Bastard Society
Requires at least: 5.8
Tested up to: 6.4
Stable tag: 0.1.0
License: MIT

A prophetic generator plugin blending astrology, numerology, tarot, and AI-driven parables.
