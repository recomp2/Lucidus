<div class='wrap'>
  <h1>Status Page <span id="lucidus-status-led" class="lucidus-status-led"></span></h1>
  <p>Page content placeholder.</p>
</div>
