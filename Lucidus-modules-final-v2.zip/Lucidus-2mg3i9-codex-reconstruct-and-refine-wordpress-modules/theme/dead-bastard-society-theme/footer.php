<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<footer>
    <p>&copy; <?php echo esc_html( date( 'Y' ) ); ?> Dead Bastard Society</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
?>
