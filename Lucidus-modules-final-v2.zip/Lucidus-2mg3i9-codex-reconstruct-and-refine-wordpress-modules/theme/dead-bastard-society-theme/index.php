<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<div id="content">
    <h1><?php esc_html_e('Welcome to the Dead Bastard Society', 'dead-bastard-society-theme'); ?></h1>
    <p><?php esc_html_e('This is the default theme template.', 'dead-bastard-society-theme'); ?></p>
</div>
<?php
get_footer();
?>
