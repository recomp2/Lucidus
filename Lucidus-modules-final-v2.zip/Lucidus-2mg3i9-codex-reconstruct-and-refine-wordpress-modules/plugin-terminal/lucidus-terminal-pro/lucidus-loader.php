<?php
/**
 * Lucidus Loader
 *
 * Loads core modules for Lucidus Terminal Pro.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once plugin_dir_path(__FILE__) . 'lucidus-memory-loader.php';
require_once plugin_dir_path(__FILE__) . 'lucidus-core-hooks.php';
?>
