<?php
/*
Plugin Name: Lucidus Module Template
Description: Template example for custom Lucidus modules.
*/
if (!defined('ABSPATH')) { exit; }

// Example module initialization.
add_action('init', function(){
    // Module code here.
});
?>
