# Module Template

This folder provides a starting point for creating Lucidus modules.
Copy this directory, rename it, and update the init file to register
new functionality.
