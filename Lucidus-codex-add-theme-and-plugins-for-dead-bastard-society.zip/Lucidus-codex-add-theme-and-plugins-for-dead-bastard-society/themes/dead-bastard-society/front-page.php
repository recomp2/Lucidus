<?php get_header(); ?>
<main id="primary" class="site-main">
    <h1>Welcome to the Dead Bastard Society</h1>
    <p>The revolution will be televised, baked, and smoked.</p>
</main>
<?php get_footer(); ?>
