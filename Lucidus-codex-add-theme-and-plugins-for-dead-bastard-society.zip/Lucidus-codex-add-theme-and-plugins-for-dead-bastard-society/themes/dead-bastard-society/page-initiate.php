<?php /* Template Name: Initiate */
get_header(); ?>
<main id="primary" class="site-main">
    <h1>Initiate Membership</h1>
    <?php echo do_shortcode('[dbs_initiate_member]'); ?>
</main>
<?php get_footer(); ?>
