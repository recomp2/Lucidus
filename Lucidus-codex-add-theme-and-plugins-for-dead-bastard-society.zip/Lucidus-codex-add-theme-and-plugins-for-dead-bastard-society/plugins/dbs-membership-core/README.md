# DBS Membership Core

Provides a member initiation form, basic rank system, and REST API endpoints for the Dead Bastard Society.
