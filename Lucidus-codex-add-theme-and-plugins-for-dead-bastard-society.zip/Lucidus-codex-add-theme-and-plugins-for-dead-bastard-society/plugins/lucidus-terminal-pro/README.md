# Lucidus Terminal Pro

A WordPress plugin delivering the Lucidus AI command center. Admin and frontend interfaces reside in `admin/` and `templates/` respectively.
