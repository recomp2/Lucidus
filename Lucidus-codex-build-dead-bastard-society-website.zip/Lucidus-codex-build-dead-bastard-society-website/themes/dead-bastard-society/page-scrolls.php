<?php /* Template Name: Scroll Wall */
get_header(); ?>
<div class="scroll-wall">
    <h1 class="fade-in">Scroll Wall</h1>
    <?php echo do_shortcode('[scroll_wall]'); ?>
</div>
<?php get_footer(); ?>

