<?php /* Template Name: Lucidus Terminal */
get_header(); ?>
<div class="terminal-page">
    <h1 class="fade-in">Lucidus Terminal</h1>
    <?php echo do_shortcode('[lucidus_group_terminal]'); ?>
</div>
<?php get_footer(); ?>

