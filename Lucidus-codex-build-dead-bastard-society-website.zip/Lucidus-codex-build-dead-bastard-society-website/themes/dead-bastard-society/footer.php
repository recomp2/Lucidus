<footer class="site-footer">
    <p>&copy; <?php echo date('Y'); ?> Dead Bastard Society</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>

