<?php /* Template Name: Quests */
get_header(); ?>
<div class="quests">
    <h1 class="fade-in">Quests</h1>
    <?php echo do_shortcode('[quests]'); ?>
</div>
<?php get_footer(); ?>

