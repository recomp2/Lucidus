<?php get_header(); ?>
<div id="home" class="wrap">
    <h1 class="fade-in">Welcome to the Dead Bastard Society</h1>
    <p class="lead">Step beyond the veil and remember who you are.</p>
    <p><a class="btn" href="/initiate/">Begin Your Initiation</a></p>
</div>
<?php get_footer(); ?>

