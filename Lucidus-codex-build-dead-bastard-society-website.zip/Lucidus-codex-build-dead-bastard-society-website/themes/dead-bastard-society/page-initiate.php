<?php /* Template Name: Initiation */
get_header(); ?>
<div class="initiation">
    <h1 class="fade-in">Initiation</h1>
    <p>Fill in the form below to join the order.</p>
    <?php echo do_shortcode('[dbs_initiation_form]'); ?>
</div>
<?php get_footer(); ?>

