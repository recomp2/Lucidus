<?php get_header(); ?>
<div class="wrap">
    <h1 class="fade-in">You wandered into the mist...</h1>
    <p>The page you seek is lost to the void. Perhaps begin at <a href="<?php echo esc_url( home_url( '/' ) ); ?>">the start</a>.</p>
</div>
<?php get_footer(); ?>

