<?php /* Template Name: Member Profile */
get_header(); ?>
<div class="member-profile">
    <h1 class="fade-in">Member Profile</h1>
    <?php echo do_shortcode('[member_profile]'); ?>
</div>
<?php get_footer(); ?>

