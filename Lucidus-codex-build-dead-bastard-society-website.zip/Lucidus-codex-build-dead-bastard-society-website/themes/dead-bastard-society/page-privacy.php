<?php /* Template Name: Privacy */
get_header(); ?>
<div class="privacy wrap">
    <h1 class="fade-in">Privacy Policy</h1>
    <p>We store minimal data, mostly your stoner memories in JSON format. These profiles are used only to enhance your experience.</p>
</div>
<?php get_footer(); ?>

