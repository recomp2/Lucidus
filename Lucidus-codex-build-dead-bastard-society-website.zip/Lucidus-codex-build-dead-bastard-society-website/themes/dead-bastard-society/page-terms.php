<?php /* Template Name: Terms */
get_header(); ?>
<div class="terms wrap">
    <h1 class="fade-in">Terms &amp; Conditions</h1>
    <p>Your use of this site implies consent to the society rules laid out herein.</p>
</div>
<?php get_footer(); ?>

