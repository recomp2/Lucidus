<?php
// Placeholder for OpenAI helper functions
// This file can be expanded to include authentication wrappers or other utilities.
