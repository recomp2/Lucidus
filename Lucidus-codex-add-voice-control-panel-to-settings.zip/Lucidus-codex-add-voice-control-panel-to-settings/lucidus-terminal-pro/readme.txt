=== Lucidus Terminal Pro ===
Contributors: lucidus
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 0.1
License: MIT

The Lucidus Terminal Pro plugin integrates AI tools with WordPress.
