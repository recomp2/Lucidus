# Lucidus Terminal Pro

This plugin powers the Lucidus AI command center. The voice settings page allows admins to test and configure OpenAI text-to-speech voices.
