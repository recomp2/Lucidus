# Lucidus Terminal Pro

This plugin powers the Dead Bastard Society universe with custom post types and quest logic.

## Features

- Custom post types: **badge**, **patch**, and **scroll**
- Rank-based scroll unlocks
- Displays earned badges and patches on member profiles

## Installation

Upload the `lucidus-terminal-pro` folder to your WordPress plugins directory and activate via the admin panel.
