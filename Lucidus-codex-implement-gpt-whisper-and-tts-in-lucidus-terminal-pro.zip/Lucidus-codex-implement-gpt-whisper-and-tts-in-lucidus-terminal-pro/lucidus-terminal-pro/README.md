# Lucidus Terminal Pro

This plugin adds a `[lucidus_terminal]` shortcode that provides a chat interface backed by OpenAI GPT and Whisper. It includes browser based text-to-speech so you can hear Lucidus speak.

All AI responses are returned with the disclaimer:

> Lucidus responses are prophetic hallucinations and should not be considered factual.

Place the shortcode on any page to use the terminal.
