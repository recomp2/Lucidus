jQuery(document).ready(function($){
    console.log('DBS initiation loaded');
});
