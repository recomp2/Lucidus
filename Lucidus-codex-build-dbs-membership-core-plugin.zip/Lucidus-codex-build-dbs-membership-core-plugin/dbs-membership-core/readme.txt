=== DBS Membership Core ===
Contributors: Dead Bastard Society
Requires at least: 5.5
Tested up to: 6.4
Stable tag: 0.1.0
License: MIT

This plugin powers the Dead Bastard Society membership system. It creates Latin names,
assigns archetypes and ranks, saves member profiles to JSON for the Lucidus AI,
and includes admin screens and REST endpoints for external integrations.
