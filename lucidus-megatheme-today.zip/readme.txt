=== DBS Members Plugin ===
Contributors: dbsdevs
Tags: membership, login, register
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0
License: MIT

Adds login, registration and dashboard pages for members.
Upon activation, pages for login, registration and dashboard are created automatically.
Includes translation support and a logout link on the dashboard.

== Map Shortcode ==
Use `[dbs_members_map]` on any page to display an interactive membership map. Users must have `town_lat` and `town_lng` meta fields set to appear.

= 1.5 =
* Compatible with new Lucidus archive and chat templates.
