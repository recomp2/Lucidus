<?php
/**
 * Template Name: Join DBS
 */
get_header(); ?>
<div class="join-form">
  <h1>Join the Brotherhood</h1>
  <?php echo do_shortcode('[dbs_initiation_form]'); ?>
</div>
<?php get_footer(); ?>
