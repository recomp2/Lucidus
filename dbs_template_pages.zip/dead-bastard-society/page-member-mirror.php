<?php
/**
 * Template Name: Member Mirror
 */
get_header(); ?>
<div class="member-mirror">
  <h1>Your Reflected Self</h1>
  <?php echo do_shortcode('[lucidus_member_mirror]'); ?>
</div>
<?php get_footer(); ?>
