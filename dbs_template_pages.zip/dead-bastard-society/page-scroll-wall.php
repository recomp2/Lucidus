<?php
/**
 * Template Name: Scroll Wall
 */
get_header(); ?>
<div class="scroll-wall">
  <h1>The Scroll Wall</h1>
  <?php echo do_shortcode('[lucidus_scroll_wall]'); ?>
</div>
<?php get_footer(); ?>
