chmod +x setup-dbs-universe.sh
./setup-dbs-universe.sh
