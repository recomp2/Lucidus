=== Dead Bastard Society Theme ===
Contributors: dbsdevs
Tags: custom, login, dashboard
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0
License: MIT

Custom theme providing integration with DBS plugins.
Includes templates for member pages and basic styling.

= 1.5 =
* Added Lucidus chat, profile, scroll feed, chapters, archive and settings templates.
* Page-specific styles loaded automatically.

= 1.6 =
* Flush rewrite rules on activation and load member styles only when needed.
* Added membership map template.
