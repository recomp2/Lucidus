<?php
// Core oracle loader placeholder
