# Lucidus Terminal Pro

A mythological OS plugin for WordPress providing memory archives, voice controls, script execution and more.

### Features
- Modular script loader with test runs
- Editable memory archive
- Voice provider selection and test phrase
- Diagnostics and upload tools
