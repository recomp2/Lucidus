<?php
// Example script for testing
function lucidus_sandbox() {
    echo "Sandbox active";
}
lucidus_sandbox();
