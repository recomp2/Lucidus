=== Lucidus Terminal Pro ===
Stable tag: 0.1.1
Contributors: drg, lucidus
License: MIT
Requires PHP: 7.4
Tags: ai, automation
