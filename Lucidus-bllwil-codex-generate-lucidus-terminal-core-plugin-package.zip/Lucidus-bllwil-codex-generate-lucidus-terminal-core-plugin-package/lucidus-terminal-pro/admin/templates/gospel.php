<div class='wrap'><h1>Gospel Page</h1><p>Page content placeholder.</p></div>
