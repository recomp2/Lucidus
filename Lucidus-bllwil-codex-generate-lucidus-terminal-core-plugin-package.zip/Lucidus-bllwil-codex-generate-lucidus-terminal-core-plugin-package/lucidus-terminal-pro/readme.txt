Lucidus Terminal Pro
====================

Installation:
1. Upload the `lucidus-terminal-pro` folder to `/wp-content/plugins/`.
2. Activate via the Plugins screen.
3. Access the new **Lucidus Terminal** menu in the WordPress admin.
