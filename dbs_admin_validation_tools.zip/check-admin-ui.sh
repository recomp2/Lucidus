#!/bin/bash
echo "🧪 Checking admin menu callback logic..."

grep -r 'add_menu_page' /Main/wp-content/plugins/ | while read line; do
  echo "🗂️ Menu page: $line"
done

grep -r 'add_submenu_page' /Main/wp-content/plugins/ | while read line; do
  echo "📎 Submenu page: $line"
done
