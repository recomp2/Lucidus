#!/bin/bash
echo "🔍 Scanning for shortcode and REST API logic..."

grep -r 'add_shortcode' /Main/wp-content/plugins/ | while read line; do
  echo "📌 Shortcode found: $line"
done

grep -r 'register_rest_route' /Main/wp-content/plugins/ | while read line; do
  echo "📡 REST endpoint found: $line"
done
