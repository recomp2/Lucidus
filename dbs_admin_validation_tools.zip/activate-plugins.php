<?php
// activate-plugins.php
// WordPress-based plugin activation script
$plugins = [
  'lucidus-terminal-pro/lucidus-terminal-pro.php',
  'lucidus-society-core/lucidus-society-core.php',
  'lucidus-core/lucidus-core.php',
  'dbs-memory-logger/dbs-memory-logger.php',
  'lucidus-panel/lucidus-panel.php',
  'dbs-openai-key-manager/dbs-openai-key-manager.php'
];

foreach ($plugins as $plugin) {
  if (!is_plugin_active($plugin)) {
    activate_plugin($plugin);
    echo "✅ Activated: $plugin\n";
  }
}
?>
